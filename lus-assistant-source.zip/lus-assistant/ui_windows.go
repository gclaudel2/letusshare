//go:build windows

package main

// Fenêtre Windows standard (user32/gdi32, sans dépendance) : un bouton « Demander de l'assistance », le code à
// dicter au téléphone, l'état, et « Arrêter et fermer ». Pas de console. Fermer la fenêtre arrête l'assistant.
import (
	"runtime"
	"strings"
	"sync"
	"sync/atomic"
	"syscall"
	"time"
	"unsafe"
)

var (
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")

	pGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	pRegisterClassExW   = user32.NewProc("RegisterClassExW")
	pCreateWindowExW    = user32.NewProc("CreateWindowExW")
	pDefWindowProcW     = user32.NewProc("DefWindowProcW")
	pGetMessageW        = user32.NewProc("GetMessageW")
	pTranslateMessage   = user32.NewProc("TranslateMessage")
	pDispatchMessageW   = user32.NewProc("DispatchMessageW")
	pPostQuitMessage    = user32.NewProc("PostQuitMessage")
	pShowWindow         = user32.NewProc("ShowWindow")
	pUpdateWindow       = user32.NewProc("UpdateWindow")
	pDestroyWindow      = user32.NewProc("DestroyWindow")
	pSetWindowTextW     = user32.NewProc("SetWindowTextW")
	pSendMessageW       = user32.NewProc("SendMessageW")
	pLoadCursorW        = user32.NewProc("LoadCursorW")
	pLoadIconW          = user32.NewProc("LoadIconW")
	pMessageBoxW        = user32.NewProc("MessageBoxW")
	pAdjustWindowRectEx = user32.NewProc("AdjustWindowRectEx")
	pGetDpiForSystem    = user32.NewProc("GetDpiForSystem")
	pSetForegroundWnd   = user32.NewProc("SetForegroundWindow")
	pGetSysColorBrush   = user32.NewProc("GetSysColorBrush")
	pMoveWindow         = user32.NewProc("MoveWindow")
	pGetWindowRect      = user32.NewProc("GetWindowRect")
	pSetWindowPos       = user32.NewProc("SetWindowPos")
	pOpenClipboard      = user32.NewProc("OpenClipboard")
	pEmptyClipboard     = user32.NewProc("EmptyClipboard")
	pSetClipboardData   = user32.NewProc("SetClipboardData")
	pCloseClipboard     = user32.NewProc("CloseClipboard")
	pGlobalAlloc        = kernel32.NewProc("GlobalAlloc")
	pGlobalLock         = kernel32.NewProc("GlobalLock")
	pGlobalUnlock       = kernel32.NewProc("GlobalUnlock")
	pShellExecuteW      = shell32.NewProc("ShellExecuteW")
	pCreateFontW        = gdi32.NewProc("CreateFontW")
	pSetTextColor       = gdi32.NewProc("SetTextColor")
	pSetBkMode          = gdi32.NewProc("SetBkMode")
)

const (
	wmDestroy        = 0x0002
	wmClose          = 0x0010
	wmSetFont        = 0x0030
	wmCommand        = 0x0111
	wmCtlColorStatic = 0x0138

	wsChild      = 0x40000000
	wsVisible    = 0x10000000
	wsTabStop    = 0x00010000
	wsWindow     = 0x00CA0000 // WS_OVERLAPPED | WS_CAPTION | WS_SYSMENU | WS_MINIMIZEBOX
	ssCenter     = 0x00000001
	bsDefPush    = 0x00000001
	mbIconError  = 0x10
	colorBtnFace = 15

	idStop     = 100
	idCopy     = 101
	idAssist   = 102
	idPairCopy = 103

	clientW = 460
)

type wndClassEx struct {
	cbSize        uint32
	style         uint32
	lpfnWndProc   uintptr
	cbClsExtra    int32
	cbWndExtra    int32
	hInstance     uintptr
	hIcon         uintptr
	hCursor       uintptr
	hbrBackground uintptr
	lpszMenuName  *uint16
	lpszClassName *uint16
	hIconSm       uintptr
}

type winMsg struct {
	hwnd    uintptr
	message uint32
	wParam  uintptr
	lParam  uintptr
	time    uint32
	ptX     int32
	ptY     int32
}

type winRect struct{ l, t, r, b int32 }

var gui struct {
	mu     sync.Mutex
	ctx    *appCtx
	hwnd   uintptr
	active int32
	dpi    int
	status string
	pair   string
	shown  bool // la session d'assistance a été demandée : le code est affiché

	hTitle, hExpl, hAssist, hCodeLbl, hCode, hCopy, hStatus, hPair, hPairCopy, hStop, hHint uintptr
}

const (
	statusIdle  = "Cliquez sur « Demander de l’assistance » pour commencer."
	titleNormal = "Let Us Share – Assistant de dépannage"
	titleActive = "Assistant de dépannage – CONTRÔLE ACTIF"
)

func utf16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

func sx(v int) int { return v * gui.dpi / 96 }

func setText(h uintptr, s string) {
	if h != 0 {
		pSetWindowTextW.Call(h, uintptr(unsafe.Pointer(utf16(s))))
	}
}

func font(face string, pt int, bold bool) uintptr {
	w := 400
	if bold {
		w = 700
	}
	h := -(pt * gui.dpi / 72)
	f, _, _ := pCreateFontW.Call(uintptr(int64(h)), 0, 0, 0, uintptr(w), 0, 0, 0, 1 /*DEFAULT_CHARSET*/, 0, 0, 5 /*CLEARTYPE*/, 0, uintptr(unsafe.Pointer(utf16(face))))
	return f
}

func pairLine(code string) string { return "Déjà dans une réunion ? Code de liaison : " + code }

func uiStatus(text string, active bool) {
	gui.mu.Lock()
	gui.status = text
	hs, hw := gui.hStatus, gui.hwnd
	gui.mu.Unlock()
	var a int32
	if active {
		a = 1
	}
	atomic.StoreInt32(&gui.active, a)
	setText(hs, text)
	if hw != 0 {
		if active {
			setText(hw, titleActive)
		} else {
			setText(hw, titleNormal)
		}
	}
}

// uiCode : nouveau code de liaison (après trop d'essais incorrects).
func uiCode(code string) {
	gui.mu.Lock()
	gui.pair = code
	h := gui.hPair
	gui.mu.Unlock()
	setText(h, pairLine(code))
}

func uiFatal(msg string) {
	pMessageBoxW.Call(0, uintptr(unsafe.Pointer(utf16(msg))), uintptr(unsafe.Pointer(utf16(titleNormal))), mbIconError)
}

// openURL : ouvre l'adresse dans le navigateur par défaut de la personne.
func openURL(u string) {
	pShellExecuteW.Call(0, uintptr(unsafe.Pointer(utf16("open"))), uintptr(unsafe.Pointer(utf16(u))), 0, 0, 1)
}

// copyText : met un texte dans le presse-papiers.
func copyText(txt string) bool {
	gui.mu.Lock()
	hw := gui.hwnd
	gui.mu.Unlock()
	if txt == "" {
		return false
	}
	u, err := syscall.UTF16FromString(txt)
	if err != nil {
		return false
	}
	if r, _, _ := pOpenClipboard.Call(hw); r == 0 {
		return false
	}
	defer pCloseClipboard.Call()
	pEmptyClipboard.Call()
	const gmemMoveable = 0x0002
	h, _, _ := pGlobalAlloc.Call(gmemMoveable, uintptr(len(u)*2))
	if h == 0 {
		return false
	}
	ptr, _, _ := pGlobalLock.Call(h)
	if ptr == 0 {
		return false
	}
	dst := unsafe.Slice((*uint16)(*(*unsafe.Pointer)(unsafe.Pointer(&ptr))), len(u)) // mémoire Windows (GlobalLock), hors du tas Go
	copy(dst, u)
	pGlobalUnlock.Call(h)
	r, _, _ := pSetClipboardData.Call(13 /*CF_UNICODETEXT*/, h)
	return r != 0
}

func flash(h uintptr, ok bool, base string) {
	if ok {
		setText(h, "Copié ✔")
	} else {
		setText(h, "Copie impossible")
	}
	time.AfterFunc(2*time.Second, func() { setText(h, base) })
}

func place(h uintptr, x, y, w, hh int) {
	pMoveWindow.Call(h, uintptr(sx(x)), uintptr(sx(y)), uintptr(sx(w)), uintptr(sx(hh)), 1)
}

func show(h uintptr, on bool) {
	f := uintptr(0) // SW_HIDE
	if on {
		f = 5 // SW_SHOW
	}
	pShowWindow.Call(h, f)
}

// relayout : dispose les contrôles ; avec le code affiché (code=true) la fenêtre est plus haute.
func relayout(code bool) {
	y := 14
	place(gui.hTitle, 20, y, 420, 26)
	y = 46
	place(gui.hExpl, 20, y, 420, 82)
	y = 136
	if code {
		place(gui.hAssist, 80, y, 300, 32)
		y += 42
		place(gui.hCodeLbl, 20, y, 420, 20)
		y += 22
		place(gui.hCode, 20, y, 420, 52)
		y += 54
		place(gui.hCopy, 150, y, 160, 30)
		y += 40
	} else {
		place(gui.hAssist, 80, y, 300, 46)
		y += 58
	}
	show(gui.hCodeLbl, code)
	show(gui.hCode, code)
	show(gui.hCopy, code)
	place(gui.hStatus, 20, y, 420, 44)
	y += 52
	place(gui.hPair, 20, y, 300, 34)
	place(gui.hPairCopy, 330, y+2, 110, 28)
	y += 46
	place(gui.hStop, 150, y, 160, 34)
	y += 44
	place(gui.hHint, 20, y, 420, 18)
	y += 24
	rc := winRect{0, 0, int32(sx(clientW)), int32(sx(y))}
	pAdjustWindowRectEx.Call(uintptr(unsafe.Pointer(&rc)), wsWindow, 0, 0)
	pSetWindowPos.Call(gui.hwnd, 0, 0, 0, uintptr(rc.r-rc.l), uintptr(rc.b-rc.t), 0x0002|0x0004) // SWP_NOMOVE | SWP_NOZORDER
}

// requestAssist : « Demander de l'assistance » — ouvre la session dans le navigateur et affiche le code à dicter.
func requestAssist() {
	c := gui.ctx
	if c == nil {
		return
	}
	c.start()
	setText(gui.hCode, pairs(c.assist))
	setText(gui.hAssist, "Rouvrir la session dans le navigateur")
	gui.shown = true
	relayout(true)
}

func wndProc(hwnd, msg, wp, lp uintptr) uintptr {
	switch msg {
	case wmCommand:
		switch wp & 0xFFFF {
		case idStop:
			pDestroyWindow.Call(hwnd)
			return 0
		case idAssist:
			requestAssist()
			return 0
		case idCopy:
			if gui.ctx != nil {
				flash(gui.hCopy, copyText(gui.ctx.assist), "Copier le code")
			}
			return 0
		case idPairCopy:
			gui.mu.Lock()
			p := strings.ReplaceAll(gui.pair, " ", "")
			gui.mu.Unlock()
			flash(gui.hPairCopy, copyText(p), "Copier")
			return 0
		}
	case wmCtlColorStatic:
		if lp != 0 && lp == gui.hStatus && atomic.LoadInt32(&gui.active) == 1 {
			pSetTextColor.Call(wp, 0x0000C0) // rouge (0x00BBGGRR)
			pSetBkMode.Call(wp, 1)           // TRANSPARENT
			b, _, _ := pGetSysColorBrush.Call(colorBtnFace)
			return b
		}
	case wmClose:
		pDestroyWindow.Call(hwnd)
		return 0
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, msg, wp, lp)
	return r
}

func uiRun(c *appCtx) {
	runtime.LockOSThread()
	gui.ctx = c
	gui.pair = c.pair
	gui.dpi = 96
	if pGetDpiForSystem.Find() == nil {
		if d, _, _ := pGetDpiForSystem.Call(); d >= 96 {
			gui.dpi = int(d)
		}
	}
	hinst, _, _ := pGetModuleHandleW.Call(0)
	cursor, _, _ := pLoadCursorW.Call(0, 32512) // IDC_ARROW
	icon, _, _ := pLoadIconW.Call(0, 32512)     // IDI_APPLICATION
	class := utf16("LusAssistantWnd")
	wc := wndClassEx{
		style: 3, lpfnWndProc: syscall.NewCallback(wndProc), hInstance: hinst,
		hIcon: icon, hCursor: cursor, hbrBackground: colorBtnFace + 1, lpszClassName: class, hIconSm: icon,
	}
	wc.cbSize = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	hwnd, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(class)), uintptr(unsafe.Pointer(utf16(titleNormal))),
		wsWindow, 0, 0, uintptr(sx(clientW)), uintptr(sx(300)), 0, 0, hinst, 0)
	if hwnd == 0 {
		uiFatal("Impossible d’ouvrir la fenêtre de l’assistant.")
		return
	}
	gui.hwnd = hwnd

	fN, fB, fT, fC, fBtn := font("Segoe UI", 9, false), font("Segoe UI", 9, true), font("Segoe UI", 12, true), font("Segoe UI", 30, true), font("Segoe UI", 11, true)
	mk := func(cls, text string, style uint32, id uintptr, f uintptr) uintptr {
		h, _, _ := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(utf16(cls))), uintptr(unsafe.Pointer(utf16(text))), uintptr(style|wsChild|wsVisible),
			0, 0, 10, 10, hwnd, id, hinst, 0)
		pSendMessageW.Call(h, wmSetFont, f, 1)
		return h
	}
	gui.mu.Lock()
	st := gui.status
	gui.mu.Unlock()
	if st == "" {
		st = statusIdle
	}
	gui.hTitle = mk("STATIC", "Assistant de dépannage", 0, 0, fT)
	gui.hExpl = mk("STATIC", "Besoin d’aide ? Cliquez sur « Demander de l’assistance » : une session Let Us Share s’ouvre dans votre navigateur, et vous obtenez un code à donner par téléphone à la personne qui vous aide. Elle ne pourra agir sur votre ordinateur que si vous l’acceptez.", 0, 0, fN)
	gui.hAssist = mk("BUTTON", "Demander de l’assistance", wsTabStop|bsDefPush, idAssist, fBtn)
	gui.hCodeLbl = mk("STATIC", "Code à donner à la personne qui vous aide :", ssCenter, 0, fB)
	gui.hCode = mk("STATIC", pairs(c.assist), ssCenter, 0, fC)
	gui.hCopy = mk("BUTTON", "Copier le code", wsTabStop, idCopy, fN)
	gui.hStatus = mk("STATIC", st, ssCenter, 0, fN)
	gui.hPair = mk("STATIC", pairLine(c.pair), 0, 0, fN)
	gui.hPairCopy = mk("BUTTON", "Copier", wsTabStop, idPairCopy, fN)
	gui.hStop = mk("BUTTON", "Arrêter et fermer", wsTabStop, idStop, fN)
	gui.hHint = mk("STATIC", "Fermer cette fenêtre arrête tout, à tout moment.", ssCenter, 0, fN)
	relayout(false)

	// centrage sur l'écran, d'après la taille réelle de la fenêtre
	var wr winRect
	pGetWindowRect.Call(hwnd, uintptr(unsafe.Pointer(&wr)))
	scrW, _, _ := pGetSystemMetrics.Call(0)
	scrH, _, _ := pGetSystemMetrics.Call(1)
	x, y := (int(scrW)-int(wr.r-wr.l))/2, (int(scrH)-int(wr.b-wr.t))/3
	if x < 0 {
		x = 0
	}
	if y < 0 {
		y = 0
	}
	pSetWindowPos.Call(hwnd, 0, uintptr(x), uintptr(y), 0, 0, 0x0001|0x0004) // SWP_NOSIZE | SWP_NOZORDER

	pShowWindow.Call(hwnd, 1)
	pUpdateWindow.Call(hwnd)
	pSetForegroundWnd.Call(hwnd)
	if atomic.LoadInt32(&gui.active) == 1 {
		setText(hwnd, titleActive)
	}
	if c.auto {
		requestAssist()
	}

	var m winMsg
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
}
