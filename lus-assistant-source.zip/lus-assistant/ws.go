package main

// Serveur WebSocket minimal (RFC 6455), bibliothèque standard uniquement.
// Suffisant pour recevoir les petits messages JSON de la page locale.

import (
	"bufio"
	"crypto/sha1"
	"encoding/base64"
	"encoding/binary"
	"errors"
	"io"
	"net"
	"net/http"
	"strings"
)

const wsMagic = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

type wsConn struct {
	c  net.Conn
	rw *bufio.ReadWriter
}

func wsAccept(w http.ResponseWriter, r *http.Request) (*wsConn, error) {
	if !strings.Contains(strings.ToLower(r.Header.Get("Upgrade")), "websocket") {
		return nil, errors.New("pas une requête websocket")
	}
	key := r.Header.Get("Sec-WebSocket-Key")
	if key == "" {
		return nil, errors.New("clé websocket absente")
	}
	hj, ok := w.(http.Hijacker)
	if !ok {
		return nil, errors.New("hijack indisponible")
	}
	conn, rw, err := hj.Hijack()
	if err != nil {
		return nil, err
	}
	sum := sha1.Sum([]byte(key + wsMagic))
	accept := base64.StdEncoding.EncodeToString(sum[:])
	resp := "HTTP/1.1 101 Switching Protocols\r\n" +
		"Upgrade: websocket\r\nConnection: Upgrade\r\n" +
		"Sec-WebSocket-Accept: " + accept + "\r\n\r\n"
	if _, err := rw.WriteString(resp); err != nil {
		conn.Close()
		return nil, err
	}
	if err := rw.Flush(); err != nil {
		conn.Close()
		return nil, err
	}
	return &wsConn{c: conn, rw: rw}, nil
}

// read lit une trame. Renvoie l'opcode et la charge utile (démasquée).
func (ws *wsConn) read(max int) (byte, []byte, error) {
	var hdr [2]byte
	if _, err := io.ReadFull(ws.rw, hdr[:]); err != nil {
		return 0, nil, err
	}
	op := hdr[0] & 0x0f
	masked := hdr[1]&0x80 != 0
	ln := int(hdr[1] & 0x7f)
	switch ln {
	case 126:
		var e [2]byte
		if _, err := io.ReadFull(ws.rw, e[:]); err != nil {
			return 0, nil, err
		}
		ln = int(binary.BigEndian.Uint16(e[:]))
	case 127:
		var e [8]byte
		if _, err := io.ReadFull(ws.rw, e[:]); err != nil {
			return 0, nil, err
		}
		ln = int(binary.BigEndian.Uint64(e[:]))
	}
	if ln < 0 || ln > max {
		return 0, nil, errors.New("trame trop grande")
	}
	var mask [4]byte
	if masked {
		if _, err := io.ReadFull(ws.rw, mask[:]); err != nil {
			return 0, nil, err
		}
	}
	payload := make([]byte, ln)
	if _, err := io.ReadFull(ws.rw, payload); err != nil {
		return 0, nil, err
	}
	if masked {
		for i := range payload {
			payload[i] ^= mask[i&3]
		}
	}
	return op, payload, nil
}

func (ws *wsConn) write(op byte, data []byte) error {
	hdr := []byte{0x80 | op}
	n := len(data)
	switch {
	case n < 126:
		hdr = append(hdr, byte(n))
	case n < 65536:
		hdr = append(hdr, 126, byte(n>>8), byte(n))
	default:
		hdr = append(hdr, 127)
		var b [8]byte
		binary.BigEndian.PutUint64(b[:], uint64(n))
		hdr = append(hdr, b[:]...)
	}
	if _, err := ws.rw.Write(hdr); err != nil {
		return err
	}
	if _, err := ws.rw.Write(data); err != nil {
		return err
	}
	return ws.rw.Flush()
}

func (ws *wsConn) writeText(s string) error { return ws.write(0x1, []byte(s)) }

func (ws *wsConn) close() {
	ws.write(0x8, nil)
	ws.c.Close()
}
