//go:build !windows

package main

import "log"

// Implémentation « à blanc » pour les systèmes autres que Windows : elle n'agit sur rien,
// elle journalise seulement. Sert à la mise au point ; l'assistant réel est l'exécutable Windows.
type dryInjector struct{}

func newInjector() Injector { return &dryInjector{} }

func (d *dryInjector) Screen() (int, int) { return 1920, 1080 }

func (d *dryInjector) Dispatch(e Event) {
	log.Printf("DRY %s x=%.3f y=%.3f b=%d dx=%.0f dy=%.0f key=%q ctrl=%v alt=%v shift=%v meta=%v",
		e.K, e.X, e.Y, e.B, e.Dx, e.Dy, e.Key, e.Ctrl, e.Alt, e.Shift, e.Meta)
}

func (d *dryInjector) ReleaseAll() { log.Printf("DRY release-all") }
