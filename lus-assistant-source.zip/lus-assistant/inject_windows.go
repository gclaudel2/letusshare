//go:build windows

package main

// Implémentation Windows : rejoue souris et clavier via les fonctions standard de user32.dll.
// Aucune dépendance externe, aucun pilote, aucun droit administrateur.
import (
	"strconv"
	"strings"
	"syscall"
	"unsafe"
)

var (
	user32              = syscall.NewLazyDLL("user32.dll")
	pSetCursorPos       = user32.NewProc("SetCursorPos")
	pMouseEvent         = user32.NewProc("mouse_event")
	pKeybdEvent         = user32.NewProc("keybd_event")
	pGetSystemMetrics   = user32.NewProc("GetSystemMetrics")
	pSetProcessDPIAware = user32.NewProc("SetProcessDPIAware")
	pVkKeyScanW         = user32.NewProc("VkKeyScanW")
	pMapVirtualKeyW     = user32.NewProc("MapVirtualKeyW")

	pEnumWindows         = user32.NewProc("EnumWindows")
	pGetWindowTextW      = user32.NewProc("GetWindowTextW")
	pIsWindowVisible     = user32.NewProc("IsWindowVisible")
	pIsIconic            = user32.NewProc("IsIconic")
	pIsWindow            = user32.NewProc("IsWindow")
	pGetWindowLongW      = user32.NewProc("GetWindowLongW")
	pGetForegroundWindow = user32.NewProc("GetForegroundWindow")
	pSetForegroundWindow = user32.NewProc("SetForegroundWindow")
	pEnumDisplayMonitors = user32.NewProc("EnumDisplayMonitors")
	pGetMonitorInfoW     = user32.NewProc("GetMonitorInfoW")
	dwmapi               = syscall.NewLazyDLL("dwmapi.dll")
	pDwmGetWindowAttr    = dwmapi.NewProc("DwmGetWindowAttribute")
)

type scrRECT struct{ L, T, R, B int32 }

func (r scrRECT) toRect() rect { return rect{int(r.L), int(r.T), int(r.R), int(r.B)} }

// scrRect : zone visible de la fenêtre (sans les marges d'ombre invisibles de Windows 10/11), ou faux si elle n'existe plus ou est réduite.
func scrRect(h uintptr) (rect, bool) {
	if h == 0 {
		return rect{}, false
	}
	if ok, _, _ := pIsWindow.Call(h); ok == 0 {
		return rect{}, false
	}
	if ic, _, _ := pIsIconic.Call(h); ic != 0 {
		return rect{}, false
	}
	var r scrRECT
	if hr, _, _ := pDwmGetWindowAttr.Call(h, 9, uintptr(unsafe.Pointer(&r)), unsafe.Sizeof(r)); hr != 0 { // DWMWA_EXTENDED_FRAME_BOUNDS
		if ok, _, _ := pGetWindowRect.Call(h, uintptr(unsafe.Pointer(&r))); ok == 0 {
			return rect{}, false
		}
	}
	return r.toRect(), true
}

var enumOut []winInfo
var enumWinCb = syscall.NewCallback(func(h, _ uintptr) uintptr {
	if v, _, _ := pIsWindowVisible.Call(h); v == 0 {
		return 1
	}
	if ic, _, _ := pIsIconic.Call(h); ic != 0 {
		return 1
	}
	if ex, _, _ := pGetWindowLongW.Call(h, uintptr(0xFFFFFFEC)); ex&0x80 != 0 { // WS_EX_TOOLWINDOW
		return 1
	}
	var cloaked uint32
	if hr, _, _ := pDwmGetWindowAttr.Call(h, 14, uintptr(unsafe.Pointer(&cloaked)), 4); hr == 0 && cloaked != 0 { // fenêtres « cachées » (autres bureaux, applications suspendues)
		return 1
	}
	buf := make([]uint16, 512)
	n, _, _ := pGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), 512)
	if n == 0 {
		return 1
	}
	title := syscall.UTF16ToString(buf[:n])
	if title == "Program Manager" {
		return 1
	}
	r, ok := scrRect(h)
	if !ok || r.W() < 40 || r.H() < 40 {
		return 1
	}
	enumOut = append(enumOut, winInfo{H: h, Title: title, R: r})
	return 1
})

// listWindows : fenêtres visibles, de la plus haute à la plus basse dans l'ordre d'empilement.
func listWindows() []winInfo {
	enumOut = nil
	pEnumWindows.Call(enumWinCb, 0)
	return append([]winInfo(nil), enumOut...)
}

type monInfo struct {
	Size    uint32
	Monitor scrRECT
	Work    scrRECT
	Flags   uint32
}

var monOut []rect
var monPrimary = -1
var enumMonCb = syscall.NewCallback(func(hm, _, _, _ uintptr) uintptr {
	mi := monInfo{Size: uint32(unsafe.Sizeof(monInfo{}))}
	if ok, _, _ := pGetMonitorInfoW.Call(hm, uintptr(unsafe.Pointer(&mi))); ok != 0 {
		if mi.Flags&1 != 0 {
			monPrimary = len(monOut)
		}
		monOut = append(monOut, mi.Monitor.toRect())
	}
	return 1
})

// listMonitors : écrans connectés, l'écran principal en premier.
func listMonitors() []rect {
	monOut, monPrimary = nil, -1
	pEnumDisplayMonitors.Call(0, 0, enumMonCb, 0)
	if len(monOut) == 0 {
		w, _, _ := pGetSystemMetrics.Call(0)
		h, _, _ := pGetSystemMetrics.Call(1)
		return []rect{{0, 0, int(w), int(h)}}
	}
	if monPrimary > 0 {
		monOut[0], monOut[monPrimary] = monOut[monPrimary], monOut[0]
	}
	return append([]rect(nil), monOut...)
}

var _ = strings.TrimSpace

const (
	mouseMove       = 0x0001
	mouseLeftDown   = 0x0002
	mouseLeftUp     = 0x0004
	mouseRightDown  = 0x0008
	mouseRightUp    = 0x0010
	mouseMiddleDown = 0x0020
	mouseMiddleUp   = 0x0040
	mouseXDown      = 0x0080
	mouseXUp        = 0x0100
	mouseWheel      = 0x0800
	mouseHWheel     = 0x1000

	keyUp       = 0x0002
	keyExtended = 0x0001
)

type winInjector struct {
	w, h  int
	scr   rect    // écran partagé
	mode  int     // 0 : écran, 1 : fenêtre ou onglet
	hwnd  uintptr // fenêtre partagée
	surf  string
	vw    int
	vh    int
	label string
	mods  map[int]bool // modificateurs enfoncés (VK)
	held  map[int]bool // touches nommées enfoncées (VK)
	btns  map[int]bool // boutons souris enfoncés
}

func newInjector() Injector {
	pSetProcessDPIAware.Call()
	w, _, _ := pGetSystemMetrics.Call(0)
	h, _, _ := pGetSystemMetrics.Call(1)
	wi := &winInjector{w: int(w), h: int(h), mods: map[int]bool{}, held: map[int]bool{}, btns: map[int]bool{}}
	wi.scr = rect{0, 0, int(w), int(h)}
	if wi.w == 0 {
		wi.w = 1920
	}
	if wi.h == 0 {
		wi.h = 1080
	}
	wi.scr = rect{0, 0, wi.w, wi.h}
	if ms := listMonitors(); len(ms) > 0 {
		wi.scr = ms[0]
	}
	return wi
}

func (wi *winInjector) Screen() (int, int) { return wi.w, wi.h }

func (wi *winInjector) move(x, y float64) {
	r, ok := wi.area()
	if !ok {
		return // la fenêtre partagée est introuvable (fermée, réduite) : on n'agit pas ailleurs par erreur
	}
	px, py := mapPoint(r, x, y)
	pSetCursorPos.Call(uintptr(px), uintptr(py))
}

// area : la zone de l'écran qui correspond à l'image partagée (écran entier, fenêtre ou onglet), relue à chaque fois : la fenêtre peut bouger.
func (wi *winInjector) area() (rect, bool) {
	if wi.mode != 1 {
		return wi.scr, true
	}
	if r, ok := scrRect(wi.hwnd); ok {
		return surfaceRect(wi.surf, r, wi.vw, wi.vh), true
	}
	if _, ok := wi.SetTarget(wi.surf, wi.vw, wi.vh, wi.label); ok { // la fenêtre a changé : on la cherche à nouveau
		if r, ok := scrRect(wi.hwnd); ok {
			return surfaceRect(wi.surf, r, wi.vw, wi.vh), true
		}
	}
	return rect{}, false
}

func (wi *winInjector) SetTarget(surf string, vw, vh int, label string) (string, bool) {
	wi.surf, wi.vw, wi.vh, wi.label = surf, vw, vh, label
	switch surf {
	case "window", "browser":
		ws := listWindows()
		i, ok := pickWindow(ws, surf, label, vw, vh)
		if !ok {
			wi.mode = 1
			wi.hwnd = 0
			return "", false
		}
		wi.mode, wi.hwnd = 1, ws[i].H
		return ws[i].Title, true
	case "monitor":
		ms := listMonitors()
		i := pickMonitor(ms, vw, vh)
		wi.mode, wi.scr = 0, ms[i]
		if len(ms) > 1 {
			return "écran " + strconv.Itoa(i+1) + " sur " + strconv.Itoa(len(ms)), true
		}
		return "écran entier", true
	}
	wi.mode, wi.scr = 0, listMonitors()[0]
	return "écran entier", true
}

// focus : met la fenêtre partagée au premier plan avant un clic, pour qu'il atteigne bien elle et non une fenêtre qui la recouvre.
func (wi *winInjector) focus() {
	if wi.mode != 1 || wi.hwnd == 0 {
		return
	}
	if fg, _, _ := pGetForegroundWindow.Call(); fg == wi.hwnd {
		return
	}
	if ic, _, _ := pIsIconic.Call(wi.hwnd); ic != 0 {
		pShowWindow.Call(wi.hwnd, 9) // SW_RESTORE
	}
	pSetForegroundWindow.Call(wi.hwnd)
}

func (wi *winInjector) mouse(flags uint32, data int32) {
	pMouseEvent.Call(uintptr(flags), 0, 0, uintptr(uint32(data)), 0)
}

// boutons : 0 gauche, 1 milieu, 2 droit, 3/4 boutons latéraux
func btnFlags(b int) (down, up uint32, xdata int32, ok bool) {
	switch b {
	case 0:
		return mouseLeftDown, mouseLeftUp, 0, true
	case 1:
		return mouseMiddleDown, mouseMiddleUp, 0, true
	case 2:
		return mouseRightDown, mouseRightUp, 0, true
	case 3:
		return mouseXDown, mouseXUp, 1, true
	case 4:
		return mouseXDown, mouseXUp, 2, true
	}
	return 0, 0, 0, false
}

func isExtended(vk int) bool {
	switch {
	case vk >= 0x21 && vk <= 0x28: // PageUp..Down, End, Home, flèches
		return true
	case vk == 0x2D || vk == 0x2E: // Insert, Delete
		return true
	case vk == 0x5B || vk == 0x5C || vk == 0x5D: // Win gauche/droite, Menu
		return true
	}
	return false
}

func (wi *winInjector) keyRaw(vk int, up bool) {
	var f uint32
	if up {
		f = keyUp
	}
	if isExtended(vk) {
		f |= keyExtended
	}
	sc, _, _ := pMapVirtualKeyW.Call(uintptr(uint32(vk)), 0)
	pKeybdEvent.Call(uintptr(byte(vk)), uintptr(byte(sc)), uintptr(f), 0)
}

func (wi *winInjector) tap(vk int) {
	wi.keyRaw(vk, false)
	wi.keyRaw(vk, true)
}

var namedKeys = map[string]int{
	"Enter": 0x0D, "Escape": 0x1B, "Backspace": 0x08, "Tab": 0x09,
	"Delete": 0x2E, "Insert": 0x2D, "Home": 0x24, "End": 0x23,
	"PageUp": 0x21, "PageDown": 0x22,
	"ArrowLeft": 0x25, "ArrowUp": 0x26, "ArrowRight": 0x27, "ArrowDown": 0x28,
	"ContextMenu": 0x5D, "CapsLock": 0x14, "NumLock": 0x90, "ScrollLock": 0x91,
	"PrintScreen": 0x2C, "Pause": 0x13,
	"F1": 0x70, "F2": 0x71, "F3": 0x72, "F4": 0x73, "F5": 0x74, "F6": 0x75,
	"F7": 0x76, "F8": 0x77, "F9": 0x78, "F10": 0x79, "F11": 0x7A, "F12": 0x7B,
}

var modVK = map[string]int{"Shift": 0x10, "Control": 0x11, "Alt": 0x12, "Meta": 0x5B}

// typeChar : saisit un caractère imprimable en trouvant sa touche sur la disposition
// du clavier de CET ordinateur (AZERTY, QWERTZ, etc.), modificateurs compris.
func (wi *winInjector) typeChar(e Event) {
	r := []rune(e.Key)
	if len(r) == 0 {
		return
	}
	res, _, _ := pVkKeyScanW.Call(uintptr(uint16(r[0])))
	code := int16(res)
	if code == -1 {
		return
	}
	vk := int(code & 0xFF)
	state := (code >> 8) & 7
	if vk == 0xFF {
		return
	}
	want := map[int]bool{}
	if state&1 != 0 {
		want[0x10] = true // Shift
	}
	if state&2 != 0 {
		want[0x11] = true // Control
	}
	if state&4 != 0 {
		want[0x12] = true // Alt
	}
	// Un raccourci en cours (Ctrl/Alt/Win tenu par l'utilisateur distant) ne doit pas être relâché.
	shortcut := (e.Ctrl && !e.Alt) || (e.Alt && !e.Ctrl) || e.Meta
	var rel, prs []int
	for _, m := range []int{0x10, 0x11, 0x12} {
		h := wi.mods[m]
		w := want[m]
		if w && !h {
			prs = append(prs, m)
		}
		if h && !w && !shortcut {
			rel = append(rel, m)
		}
	}
	for _, m := range rel {
		wi.keyRaw(m, true)
	}
	for _, m := range prs {
		wi.keyRaw(m, false)
	}
	wi.tap(vk)
	for _, m := range prs {
		wi.keyRaw(m, true)
	}
	for _, m := range rel {
		wi.keyRaw(m, false)
	}
}

func (wi *winInjector) Dispatch(e Event) {
	switch e.K {
	case "mm":
		wi.move(e.X, e.Y)
	case "md":
		wi.focus()
		wi.move(e.X, e.Y)
		if d, _, x, ok := btnFlags(e.B); ok {
			wi.btns[e.B] = true
			wi.mouse(d, x)
		}
	case "mu":
		wi.move(e.X, e.Y)
		if _, u, x, ok := btnFlags(e.B); ok {
			delete(wi.btns, e.B)
			wi.mouse(u, x)
		}
	case "wh":
		if e.Dy != 0 {
			v := -e.Dy * 1.2
			wi.mouse(mouseWheel, clampI(v))
		}
		if e.Dx != 0 {
			v := e.Dx * 1.2
			wi.mouse(mouseHWheel, clampI(v))
		}
	case "kd":
		if vk, ok := modVK[e.Key]; ok {
			wi.mods[vk] = true
			wi.keyRaw(vk, false)
		} else if vk, ok := namedKeys[e.Key]; ok {
			wi.held[vk] = true
			wi.keyRaw(vk, false)
		} else if len([]rune(e.Key)) == 1 {
			wi.typeChar(e)
		}
	case "ku":
		if vk, ok := modVK[e.Key]; ok {
			delete(wi.mods, vk)
			wi.keyRaw(vk, true)
		} else if vk, ok := namedKeys[e.Key]; ok {
			delete(wi.held, vk)
			wi.keyRaw(vk, true)
		}
	case "release":
		wi.ReleaseAll()
	}
}

func clampI(v float64) int32 {
	if v > 1200 {
		v = 1200
	}
	if v < -1200 {
		v = -1200
	}
	return int32(v)
}

// ReleaseAll : relâche tout ce qui reste enfoncé (sécurité en fin de contrôle ou à la déconnexion).
func (wi *winInjector) ReleaseAll() {
	for vk := range wi.held {
		wi.keyRaw(vk, true)
	}
	for vk := range wi.mods {
		wi.keyRaw(vk, true)
	}
	for b := range wi.btns {
		if _, u, x, ok := btnFlags(b); ok {
			wi.mouse(u, x)
		}
	}
	wi.held = map[int]bool{}
	wi.mods = map[int]bool{}
	wi.btns = map[int]bool{}
}
