// p2p-relay : relais TURN minimal (RFC 8656) en Go, bibliothèque standard uniquement.
// - UDP + TCP (+ TLS optionnel) sur le même port ou un port TLS dédié (ex. 443)
// - identifiants temporaires "REST" compatibles coturn (use-auth-secret) ou identifiant fixe
// - le relais ne voit jamais le contenu : DTLS-SRTP reste chiffré de bout en bout entre les pairs
package main

import (
	"bufio"
	"crypto/hmac"
	"crypto/md5"
	"crypto/rand"
	"crypto/sha1"
	"crypto/tls"
	"encoding/base64"
	"encoding/binary"
	"encoding/hex"
	"errors"
	"flag"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"os"
	"os/signal"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	magic  = 0x2112A442
	hdrLen = 20

	mBinding    = 0x001
	mAllocate   = 0x003
	mRefresh    = 0x004
	mSend       = 0x006
	mData       = 0x007
	mCreatePerm = 0x008
	mChanBind   = 0x009

	cReq = 0x0000
	cInd = 0x0010
	cOK  = 0x0100
	cErr = 0x0110

	aUsername     = 0x0006
	aMI           = 0x0008
	aErrCode      = 0x0009
	aChannel      = 0x000C
	aLifetime     = 0x000D
	aXorPeer      = 0x0012
	aData         = 0x0013
	aRealm        = 0x0014
	aNonce        = 0x0015
	aXorRelayed   = 0x0016
	aReqTransport = 0x0019
	aXorMapped    = 0x0020
	aSoftware     = 0x8022

	defLifetime = 600
	maxLifetime = 3600
	permTTL     = 5 * time.Minute
)

// ---------- encodage / décodage STUN ----------

type attr struct {
	t   uint16
	v   []byte
	off int
}
type msg struct {
	typ   uint16
	txid  [12]byte
	attrs []attr
	raw   []byte
}

func enc(method, class uint16) uint16 {
	return (method & 0xF) | ((method & 0x70) << 1) | ((method & 0xF80) << 2) | class
}

func parse(b []byte) (*msg, error) {
	if len(b) < hdrLen || binary.BigEndian.Uint32(b[4:8]) != magic {
		return nil, errors.New("pas STUN")
	}
	l := int(binary.BigEndian.Uint16(b[2:4]))
	if l%4 != 0 || hdrLen+l > len(b) {
		return nil, errors.New("longueur invalide")
	}
	m := &msg{typ: binary.BigEndian.Uint16(b[0:2]), raw: b[:hdrLen+l]}
	copy(m.txid[:], b[8:20])
	for i := hdrLen; i+4 <= hdrLen+l; {
		t := binary.BigEndian.Uint16(b[i : i+2])
		al := int(binary.BigEndian.Uint16(b[i+2 : i+4]))
		if i+4+al > hdrLen+l {
			return nil, errors.New("attribut tronqué")
		}
		m.attrs = append(m.attrs, attr{t, b[i+4 : i+4+al], i})
		i += 4 + ((al + 3) &^ 3)
	}
	return m, nil
}
func (m *msg) get(t uint16) []byte {
	for _, a := range m.attrs {
		if a.t == t {
			return a.v
		}
	}
	return nil
}
func (m *msg) getAll(t uint16) [][]byte {
	var r [][]byte
	for _, a := range m.attrs {
		if a.t == t {
			r = append(r, a.v)
		}
	}
	return r
}
func (m *msg) checkMI(key []byte) bool {
	for _, a := range m.attrs {
		if a.t == aMI && len(a.v) == 20 {
			tmp := make([]byte, a.off)
			copy(tmp, m.raw[:a.off])
			binary.BigEndian.PutUint16(tmp[2:4], uint16(a.off+24-hdrLen))
			mac := hmac.New(sha1.New, key)
			mac.Write(tmp)
			return hmac.Equal(mac.Sum(nil), a.v)
		}
	}
	return false
}

type builder struct{ b []byte }

func newMsg(typ uint16, txid [12]byte) *builder {
	b := make([]byte, hdrLen)
	binary.BigEndian.PutUint16(b[0:2], typ)
	binary.BigEndian.PutUint32(b[4:8], magic)
	copy(b[8:20], txid[:])
	return &builder{b}
}
func (x *builder) add(t uint16, v []byte) {
	h := make([]byte, 4)
	binary.BigEndian.PutUint16(h[0:2], t)
	binary.BigEndian.PutUint16(h[2:4], uint16(len(v)))
	x.b = append(x.b, h...)
	x.b = append(x.b, v...)
	for len(x.b)%4 != 0 {
		x.b = append(x.b, 0)
	}
}
func (x *builder) finish(key []byte) []byte {
	if key != nil {
		binary.BigEndian.PutUint16(x.b[2:4], uint16(len(x.b)-hdrLen+24))
		mac := hmac.New(sha1.New, key)
		mac.Write(x.b)
		x.add(aMI, mac.Sum(nil))
	}
	binary.BigEndian.PutUint16(x.b[2:4], uint16(len(x.b)-hdrLen))
	return x.b
}

var magicBytes = [4]byte{0x21, 0x12, 0xA4, 0x42}

func xorAddr(ip net.IP, port int, txid [12]byte) []byte {
	if ip4 := ip.To4(); ip4 != nil {
		b := make([]byte, 8)
		b[1] = 1
		binary.BigEndian.PutUint16(b[2:4], uint16(port)^uint16(magic>>16))
		for i := 0; i < 4; i++ {
			b[4+i] = ip4[i] ^ magicBytes[i]
		}
		return b
	}
	b := make([]byte, 20)
	b[1] = 2
	binary.BigEndian.PutUint16(b[2:4], uint16(port)^uint16(magic>>16))
	ip16 := ip.To16()
	k := append(magicBytes[:], txid[:]...)
	for i := 0; i < 16; i++ {
		b[4+i] = ip16[i] ^ k[i]
	}
	return b
}
func parseXorAddr(v []byte, txid [12]byte) (net.IP, int, bool) {
	if len(v) < 8 {
		return nil, 0, false
	}
	port := int(binary.BigEndian.Uint16(v[2:4]) ^ uint16(magic>>16))
	switch v[1] {
	case 1:
		ip := make(net.IP, 4)
		for i := 0; i < 4; i++ {
			ip[i] = v[4+i] ^ magicBytes[i]
		}
		return ip, port, true
	case 2:
		if len(v) < 20 {
			return nil, 0, false
		}
		k := append(magicBytes[:], txid[:]...)
		ip := make(net.IP, 16)
		for i := 0; i < 16; i++ {
			ip[i] = v[4+i] ^ k[i]
		}
		return ip, port, true
	}
	return nil, 0, false
}
func errAttr(code int, reason string) []byte {
	b := []byte{0, 0, byte(code / 100), byte(code % 100)}
	return append(b, []byte(reason)...)
}
func u32(v uint32) []byte { b := make([]byte, 4); binary.BigEndian.PutUint32(b, v); return b }

// ---------- serveur ----------

type client struct {
	key    string
	remote net.Addr
	tcp    bool
	write  func([]byte) error
}

type alloc struct {
	mu       sync.Mutex
	c        *client
	relay    *net.UDPConn
	relayAdv *net.UDPAddr
	user     string
	expiry   time.Time
	perms    map[string]time.Time
	chToPeer map[uint16]*net.UDPAddr
	peerToCh map[string]uint16
}

type srv struct {
	mu                    sync.Mutex
	allocs                map[string]*alloc
	realm, nonce          string
	secret, user, pass    string
	relayIP               net.IP
	minPort, maxPort      int
	maxAllocs             int
	quiet                 bool
	totalAlloc, totalDrop int
}

func mname(m uint16) string {
	switch m {
	case mBinding:
		return "Binding"
	case mAllocate:
		return "Allocate"
	case mRefresh:
		return "Refresh"
	case mCreatePerm:
		return "CreatePermission"
	case mChanBind:
		return "ChannelBind"
	}
	return fmt.Sprintf("méthode %#x", m)
}

func (c *client) proto() string {
	if c.tcp {
		return "TCP"
	}
	return "UDP"
}

func (s *srv) logf(f string, a ...any) {
	if !s.quiet {
		log.Printf(f, a...)
	}
}

func (s *srv) password(user string) (string, bool) {
	if s.user != "" && user == s.user {
		return s.pass, true
	}
	if s.secret != "" {
		exp, err := strconv.ParseInt(strings.SplitN(user, ":", 2)[0], 10, 64)
		if err != nil || exp < time.Now().Unix() {
			return "", false
		}
		mac := hmac.New(sha1.New, []byte(s.secret))
		mac.Write([]byte(user))
		return base64.StdEncoding.EncodeToString(mac.Sum(nil)), true
	}
	return "", false
}

func (s *srv) reply(c *client, m *msg, method, class uint16, key []byte, fill func(*builder)) {
	b := newMsg(enc(method, class), m.txid)
	if fill != nil {
		fill(b)
	}
	c.write(b.finish(key))
}
func (s *srv) replyErr(c *client, m *msg, method uint16, code int, reason string, withRealm bool) {
	s.reply(c, m, method, cErr, nil, func(b *builder) {
		b.add(aErrCode, errAttr(code, reason))
		if withRealm {
			b.add(aRealm, []byte(s.realm))
			b.add(aNonce, []byte(s.nonce))
		}
	})
}

// auth vérifie les identifiants long terme ; renvoie la clé MESSAGE-INTEGRITY.
func (s *srv) auth(c *client, m *msg, method uint16) ([]byte, string, bool) {
	if m.get(aMI) == nil {
		s.logf("  %s de %s : sans identifiants (1er échange normal) -> 401", mname(method), c.remote)
		s.replyErr(c, m, method, 401, "Unauthorized", true)
		return nil, "", false
	}
	user := string(m.get(aUsername))
	if string(m.get(aNonce)) != s.nonce {
		s.logf("  %s de %s : nonce périmé -> 438", mname(method), c.remote)
		s.replyErr(c, m, method, 438, "Stale Nonce", true)
		return nil, "", false
	}
	pw, ok := s.password(user)
	if !ok {
		s.logf("  REFUSÉ : identifiant %q inconnu ou expiré (secret différent, ou horloge du PC décalée ?)", user)
		s.replyErr(c, m, method, 401, "Unauthorized", true)
		return nil, "", false
	}
	h := md5.Sum([]byte(user + ":" + s.realm + ":" + pw))
	key := h[:]
	if !m.checkMI(key) {
		s.logf("  REFUSÉ : intégrité invalide pour %q : le secret saisi dans la page ne correspond pas à celui du relais", user)
		s.replyErr(c, m, method, 401, "Unauthorized", true)
		return nil, "", false
	}
	return key, user, true
}

func hostPort(a net.Addr) (net.IP, int) {
	switch v := a.(type) {
	case *net.UDPAddr:
		return v.IP, v.Port
	case *net.TCPAddr:
		return v.IP, v.Port
	}
	h, p, _ := net.SplitHostPort(a.String())
	port, _ := strconv.Atoi(p)
	return net.ParseIP(h), port
}

func (s *srv) handle(c *client, data []byte) {
	if len(data) < 4 {
		return
	}
	switch data[0] >> 6 {
	case 1:
		s.onChannelData(c, data)
		return
	case 0:
	default:
		return
	}
	m, err := parse(data)
	if err != nil {
		return
	}
	method := (m.typ & 0xF) | ((m.typ >> 1) & 0x70) | ((m.typ >> 2) & 0xF80)
	class := m.typ & 0x0110
	if class == cReq {
		s.logf("requête %s de %s (%s)", mname(method), c.remote, c.proto())
	}
	if class == cInd {
		if method == mSend {
			s.onSend(c, m)
		}
		return
	}
	if class != cReq {
		return
	}
	switch method {
	case mBinding:
		ip, port := hostPort(c.remote)
		s.reply(c, m, mBinding, cOK, nil, func(b *builder) { b.add(aXorMapped, xorAddr(ip, port, m.txid)) })
	case mAllocate:
		s.onAllocate(c, m)
	case mRefresh:
		s.onRefresh(c, m)
	case mCreatePerm:
		s.onCreatePerm(c, m)
	case mChanBind:
		s.onChanBind(c, m)
	default:
		s.replyErr(c, m, method, 400, "Bad Request", false)
	}
}

func (s *srv) openRelay() (*net.UDPConn, error) {
	bind := net.IPv4zero
	if s.relayIP.IsLoopback() {
		bind = s.relayIP
	}
	span := big.NewInt(int64(s.maxPort - s.minPort + 1))
	for i := 0; i < 200; i++ {
		n, _ := rand.Int(rand.Reader, span)
		p := s.minPort + int(n.Int64())
		conn, err := net.ListenUDP("udp4", &net.UDPAddr{IP: bind, Port: p})
		if err == nil {
			conn.SetReadBuffer(4 << 20) // absorbe les rafales (vidéo, fichiers)
			conn.SetWriteBuffer(4 << 20)
			return conn, nil
		}
	}
	return nil, errors.New("plus de port libre")
}

func (s *srv) onAllocate(c *client, m *msg) {
	key, user, ok := s.auth(c, m, mAllocate)
	if !ok {
		return
	}
	s.mu.Lock()
	if _, exists := s.allocs[c.key]; exists {
		s.mu.Unlock()
		s.replyErr(c, m, mAllocate, 437, "Allocation Mismatch", false)
		return
	}
	if len(s.allocs) >= s.maxAllocs {
		s.mu.Unlock()
		s.replyErr(c, m, mAllocate, 486, "Allocation Quota Reached", false)
		return
	}
	rt := m.get(aReqTransport)
	if len(rt) < 1 || rt[0] != 17 {
		s.mu.Unlock()
		s.replyErr(c, m, mAllocate, 442, "Unsupported Transport Protocol", false)
		return
	}
	relay, err := s.openRelay()
	if err != nil {
		s.mu.Unlock()
		s.replyErr(c, m, mAllocate, 508, "Insufficient Capacity", false)
		return
	}
	adv := &net.UDPAddr{IP: s.relayIP, Port: relay.LocalAddr().(*net.UDPAddr).Port}
	a := &alloc{c: c, relay: relay, relayAdv: adv, user: user, expiry: time.Now().Add(defLifetime * time.Second),
		perms: map[string]time.Time{}, chToPeer: map[uint16]*net.UDPAddr{}, peerToCh: map[string]uint16{}}
	s.allocs[c.key] = a
	s.totalAlloc++
	n := len(s.allocs)
	s.mu.Unlock()
	go a.readLoop(s)
	label := user
	if i := strings.Index(user, ":"); i >= 0 {
		label = user[i+1:]
	}
	s.logf("allocation +1 (%d actives) client=%s via=%s utilisateur=%q relais=%s", n, c.remote, map[bool]string{true: "TCP/TLS", false: "UDP"}[c.tcp], label, adv)
	cip, cport := hostPort(c.remote)
	s.reply(c, m, mAllocate, cOK, key, func(b *builder) {
		b.add(aXorRelayed, xorAddr(adv.IP, adv.Port, m.txid))
		b.add(aLifetime, u32(defLifetime))
		b.add(aXorMapped, xorAddr(cip, cport, m.txid))
	})
}

func (s *srv) alloc(c *client) *alloc {
	s.mu.Lock()
	defer s.mu.Unlock()
	return s.allocs[c.key]
}

func (s *srv) onRefresh(c *client, m *msg) {
	key, _, ok := s.auth(c, m, mRefresh)
	if !ok {
		return
	}
	a := s.alloc(c)
	if a == nil {
		s.replyErr(c, m, mRefresh, 437, "Allocation Mismatch", false)
		return
	}
	life := uint32(defLifetime)
	if v := m.get(aLifetime); len(v) == 4 {
		life = binary.BigEndian.Uint32(v)
	}
	if life == 0 {
		s.drop(c.key)
	} else {
		if life > maxLifetime {
			life = maxLifetime
		}
		a.mu.Lock()
		a.expiry = time.Now().Add(time.Duration(life) * time.Second)
		a.mu.Unlock()
	}
	s.reply(c, m, mRefresh, cOK, key, func(b *builder) { b.add(aLifetime, u32(life)) })
}

func (s *srv) onCreatePerm(c *client, m *msg) {
	key, _, ok := s.auth(c, m, mCreatePerm)
	if !ok {
		return
	}
	a := s.alloc(c)
	if a == nil {
		s.replyErr(c, m, mCreatePerm, 437, "Allocation Mismatch", false)
		return
	}
	peers := m.getAll(aXorPeer)
	if len(peers) == 0 {
		s.replyErr(c, m, mCreatePerm, 400, "Bad Request", false)
		return
	}
	a.mu.Lock()
	for _, v := range peers {
		if ip, _, ok := parseXorAddr(v, m.txid); ok {
			a.perms[ip.String()] = time.Now().Add(permTTL)
		}
	}
	a.mu.Unlock()
	s.reply(c, m, mCreatePerm, cOK, key, nil)
}

func (s *srv) onChanBind(c *client, m *msg) {
	key, _, ok := s.auth(c, m, mChanBind)
	if !ok {
		return
	}
	a := s.alloc(c)
	if a == nil {
		s.replyErr(c, m, mChanBind, 437, "Allocation Mismatch", false)
		return
	}
	cv, pv := m.get(aChannel), m.get(aXorPeer)
	if len(cv) < 2 || pv == nil {
		s.replyErr(c, m, mChanBind, 400, "Bad Request", false)
		return
	}
	ch := binary.BigEndian.Uint16(cv[0:2])
	ip, port, ok2 := parseXorAddr(pv, m.txid)
	if !ok2 || ch < 0x4000 || ch > 0x7FFE {
		s.replyErr(c, m, mChanBind, 400, "Bad Request", false)
		return
	}
	peer := &net.UDPAddr{IP: ip, Port: port}
	a.mu.Lock()
	if old, exists := a.chToPeer[ch]; exists && old.String() != peer.String() {
		a.mu.Unlock()
		s.replyErr(c, m, mChanBind, 400, "Channel already bound", false)
		return
	}
	if oc, exists := a.peerToCh[peer.String()]; exists && oc != ch {
		a.mu.Unlock()
		s.replyErr(c, m, mChanBind, 400, "Peer already bound", false)
		return
	}
	a.chToPeer[ch] = peer
	a.peerToCh[peer.String()] = ch
	a.perms[ip.String()] = time.Now().Add(permTTL)
	a.mu.Unlock()
	s.reply(c, m, mChanBind, cOK, key, nil)
}

func (s *srv) onSend(c *client, m *msg) {
	a := s.alloc(c)
	if a == nil {
		return
	}
	pv, dv := m.get(aXorPeer), m.get(aData)
	ip, port, ok := parseXorAddr(pv, m.txid)
	if !ok || dv == nil {
		return
	}
	a.mu.Lock()
	exp, has := a.perms[ip.String()]
	a.mu.Unlock()
	if !has || time.Now().After(exp) {
		return
	}
	a.relay.WriteToUDP(dv, &net.UDPAddr{IP: ip, Port: port})
}

func (s *srv) onChannelData(c *client, d []byte) {
	if len(d) < 4 {
		return
	}
	a := s.alloc(c)
	if a == nil {
		return
	}
	ch := binary.BigEndian.Uint16(d[0:2])
	l := int(binary.BigEndian.Uint16(d[2:4]))
	if 4+l > len(d) {
		return
	}
	a.mu.Lock()
	peer := a.chToPeer[ch]
	a.mu.Unlock()
	if peer == nil {
		return
	}
	a.relay.WriteToUDP(d[4:4+l], peer)
}

// readLoop : paquets reçus des pairs -> client (ChannelData si canal lié, sinon Data indication)
func (a *alloc) readLoop(s *srv) {
	buf := make([]byte, 65536)
	for {
		n, from, err := a.relay.ReadFromUDP(buf)
		if err != nil {
			return
		}
		a.mu.Lock()
		exp, has := a.perms[from.IP.String()]
		ch, bound := a.peerToCh[from.String()]
		a.mu.Unlock()
		if !has || time.Now().After(exp) {
			continue
		}
		if bound {
			out := make([]byte, 4+n)
			binary.BigEndian.PutUint16(out[0:2], ch)
			binary.BigEndian.PutUint16(out[2:4], uint16(n))
			copy(out[4:], buf[:n])
			if a.c.tcp {
				for len(out)%4 != 0 {
					out = append(out, 0)
				}
			}
			a.c.write(out)
		} else {
			var tx [12]byte
			rand.Read(tx[:])
			b := newMsg(enc(mData, cInd), tx)
			b.add(aXorPeer, xorAddr(from.IP, from.Port, tx))
			b.add(aData, buf[:n])
			a.c.write(b.finish(nil))
		}
	}
}

func (s *srv) drop(key string) {
	s.mu.Lock()
	a := s.allocs[key]
	delete(s.allocs, key)
	n := len(s.allocs)
	if a != nil {
		s.totalDrop++
	}
	s.mu.Unlock()
	if a != nil {
		a.relay.Close()
		s.logf("allocation -1 (%d actives) client=%s", n, a.c.remote)
	}
}

func (s *srv) reaper() {
	for range time.Tick(5 * time.Second) {
		now := time.Now()
		var dead []string
		s.mu.Lock()
		for k, a := range s.allocs {
			a.mu.Lock()
			if now.After(a.expiry) {
				dead = append(dead, k)
			}
			a.mu.Unlock()
		}
		s.mu.Unlock()
		for _, k := range dead {
			s.drop(k)
		}
	}
}

func (s *srv) serveUDP(pc *net.UDPConn) {
	buf := make([]byte, 65536)
	for {
		n, addr, err := pc.ReadFromUDP(buf)
		if err != nil {
			return
		}
		d := make([]byte, n)
		copy(d, buf[:n])
		c := &client{key: "udp|" + addr.String(), remote: addr, write: func(b []byte) error { _, e := pc.WriteToUDP(b, addr); return e }}
		s.handle(c, d)
	}
}

func (s *srv) serveStream(conn net.Conn) {
	defer conn.Close()
	s.logf("connexion TCP de %s", conn.RemoteAddr())
	var wmu sync.Mutex
	c := &client{key: "tcp|" + conn.RemoteAddr().String(), remote: conn.RemoteAddr(), tcp: true,
		write: func(b []byte) error { wmu.Lock(); defer wmu.Unlock(); _, e := conn.Write(b); return e }}
	defer s.drop(c.key)
	br := bufio.NewReaderSize(conn, 65536)
	for {
		conn.SetReadDeadline(time.Now().Add(15 * time.Minute))
		hdr := make([]byte, 4)
		if _, err := io.ReadFull(br, hdr); err != nil {
			return
		}
		var total int
		switch hdr[0] >> 6 {
		case 0:
			total = hdrLen + int(binary.BigEndian.Uint16(hdr[2:4]))
		case 1:
			total = (4 + int(binary.BigEndian.Uint16(hdr[2:4])) + 3) &^ 3
		default:
			return
		}
		buf := make([]byte, total)
		copy(buf, hdr)
		if total > 4 {
			if _, err := io.ReadFull(br, buf[4:]); err != nil {
				return
			}
		}
		s.handle(c, buf)
	}
}

func (s *srv) acceptLoop(l net.Listener) {
	for {
		conn, err := l.Accept()
		if err != nil {
			return
		}
		go s.serveStream(conn)
	}
}

func randHex(n int) string { b := make([]byte, n); rand.Read(b); return hex.EncodeToString(b) }

func main() {
	listen := flag.String("listen", "127.0.0.1", "adresse d'écoute (0.0.0.0 pour toutes les interfaces)")
	port := flag.Int("port", 3478, "port UDP+TCP (0 pour désactiver)")
	tlsPort := flag.Int("tls-port", 0, "port TLS (ex. 443), nécessite -cert et -key")
	cert := flag.String("cert", "", "certificat TLS (PEM)")
	keyf := flag.String("key", "", "clé privée TLS (PEM)")
	relayIP := flag.String("relay-ip", "", "adresse IP publique annoncée pour les relais (défaut : -listen)")
	secret := flag.String("secret", "", "secret partagé pour les identifiants temporaires (aléatoire si vide)")
	user := flag.String("user", "", "identifiant fixe (optionnel)")
	pass := flag.String("pass", "", "mot de passe fixe (optionnel)")
	realm := flag.String("realm", "p2p-relay", "realm TURN")
	minP := flag.Int("min-port", 50000, "premier port UDP de relais")
	maxP := flag.Int("max-port", 50999, "dernier port UDP de relais")
	maxA := flag.Int("max-allocs", 200, "nombre maximal d'allocations simultanées")
	quiet := flag.Bool("quiet", false, "journal minimal")
	flag.Parse()

	if *secret == "" {
		*secret = os.Getenv("P2P_RELAY_SECRET") // évite de mettre le secret dans la ligne de commande (visible par ps)
	}
	if *secret == "" && *user == "" {
		*secret = randHex(16)
	}
	rip := net.ParseIP(*relayIP)
	if rip == nil {
		rip = net.ParseIP(*listen)
	}
	if rip == nil || rip.IsUnspecified() {
		fmt.Println("ERREUR : avec -listen 0.0.0.0 il faut préciser -relay-ip <adresse IP publique ou LAN>")
		os.Exit(2)
	}
	s := &srv{allocs: map[string]*alloc{}, realm: *realm, nonce: randHex(8), secret: *secret, user: *user, pass: *pass,
		relayIP: rip, minPort: *minP, maxPort: *maxP, maxAllocs: *maxA, quiet: *quiet}

	fmt.Println("=== p2p-relay : relais TURN aveugle (le contenu reste chiffré de bout en bout) ===")
	if *port > 0 {
		addr := net.JoinHostPort(*listen, strconv.Itoa(*port))
		ua, err := net.ResolveUDPAddr("udp", addr)
		if err != nil {
			log.Fatal(err)
		}
		pc, err := net.ListenUDP("udp", ua)
		if err != nil {
			log.Fatalf("UDP %s : %v", addr, err)
		}
		tl, err := net.Listen("tcp", addr)
		if err != nil {
			log.Fatalf("TCP %s : %v", addr, err)
		}
		go s.serveUDP(pc)
		go s.acceptLoop(tl)
		fmt.Printf("Écoute UDP + TCP sur %s\n", addr)
	}
	if *tlsPort > 0 {
		if *cert == "" || *keyf == "" {
			log.Fatal("-tls-port nécessite -cert et -key")
		}
		pair, err := tls.LoadX509KeyPair(*cert, *keyf)
		if err != nil {
			log.Fatalf("certificat : %v", err)
		}
		addr := net.JoinHostPort(*listen, strconv.Itoa(*tlsPort))
		tl, err := tls.Listen("tcp", addr, &tls.Config{Certificates: []tls.Certificate{pair}, MinVersion: tls.VersionTLS12})
		if err != nil {
			log.Fatalf("TLS %s : %v", addr, err)
		}
		go s.acceptLoop(tl)
		fmt.Printf("Écoute TLS sur %s\n", addr)
	}
	fmt.Printf("Adresse de relais annoncée : %s (ports UDP %d-%d)\n", rip, *minP, *maxP)
	if *secret != "" {
		fmt.Printf("Secret du relais (à saisir dans l'application) : %s\n", *secret)
		exp := time.Now().Add(24 * time.Hour).Unix()
		u := fmt.Sprintf("%d:test", exp)
		mac := hmac.New(sha1.New, []byte(*secret))
		mac.Write([]byte(u))
		fmt.Printf("Identifiants de test valables 24 h :\n  identifiant : %s\n  mot de passe : %s\n", u, base64.StdEncoding.EncodeToString(mac.Sum(nil)))
	}
	if *user != "" {
		fmt.Printf("Identifiant fixe : %s\n", *user)
	}
	fmt.Println("URL à renseigner dans l'application :")
	if *port > 0 {
		fmt.Printf("  turn:%s:%d?transport=tcp\n  turn:%s:%d?transport=udp\n", *listen, *port, *listen, *port)
	}
	if *tlsPort > 0 {
		fmt.Printf("  turns:<votre-domaine>:%d?transport=tcp\n", *tlsPort)
	}
	fmt.Println("Ctrl+C pour arrêter.")
	go s.reaper()
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	<-sig
	fmt.Printf("\nArrêt. Allocations créées : %d\n", s.totalAlloc)
}
