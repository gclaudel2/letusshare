package main

// Event : un message reçu de la page Let Us Share (ouverte sur CE même ordinateur).
// "hello" sert à l'appairage ; les autres décrivent une action souris/clavier à rejouer
// localement, uniquement pendant un contrôle que la personne a autorisé dans la réunion.
type Event struct {
	T     string  `json:"t"`   // "hello" pour l'appairage
	Tok   string  `json:"tok"` // code d'appairage affiché par cette fenêtre
	K     string  `json:"k"`   // mm, md, mu, wh, kd, ku, release
	X     float64 `json:"x"`
	Y     float64 `json:"y"`
	B     int     `json:"b"`
	Dx    float64 `json:"dx"`
	Dy    float64 `json:"dy"`
	Key   string  `json:"key"`
	Code  string  `json:"code"`
	Ctrl  bool    `json:"ctrl"`
	Alt   bool    `json:"alt"`
	Shift bool    `json:"shift"`
	Meta  bool    `json:"meta"`
	Surf  string  `json:"surf"` // "tgt" : type de surface partagée (monitor, window, browser)
	VW    int     `json:"vw"`   // "tgt" : taille de la vidéo partagée
	VH    int     `json:"vh"`
	Label string  `json:"label"` // "tgt" : titre de la fenêtre / de l'onglet partagé
}

// Injector : ce qui applique réellement les actions. Une implémentation Windows (user32)
// et une implémentation « à blanc » (autres systèmes, pour la mise au point) existent.
type Injector interface {
	Screen() (int, int)
	// SetTarget indique ce que la personne partage (écran entier, fenêtre, onglet). Les positions reçues sont relatives à cette surface :
	// l'implémentation retrouve où elle se trouve sur l'écran. Renvoie un nom lisible et si la surface a été retrouvée.
	SetTarget(surf string, vw, vh int, label string) (string, bool)
	Dispatch(e Event)
	ReleaseAll()
}
