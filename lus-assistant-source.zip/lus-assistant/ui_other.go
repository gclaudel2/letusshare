//go:build !windows

package main

import (
	"bufio"
	"fmt"
	"os"
	"os/signal"
	"time"
)

// Interface « console » pour la mise au point hors Windows.
func uiStatus(text string, active bool) {
	fmt.Printf("[%s] %s\n", time.Now().Format("15:04:05"), text)
}

func uiCode(code string) { fmt.Println("NOUVEAU CODE D'APPAIRAGE :", code) }

func uiFatal(msg string) { fmt.Println(msg) }

func openURL(u string) { fmt.Println("OUVRIR:", u) }

func uiRun(c *appCtx) {
	fmt.Println("Let Us Share – Assistant de dépannage", c.version)
	fmt.Println("        CODE D'APPAIRAGE :   ", c.pair)
	fmt.Println("Entrée ou Ctrl+C pour arrêter.")
	if c.auto {
		c.start()
		fmt.Println("CODE D'ASSISTANCE :", pairs(c.assist))
	}
	quit := make(chan struct{})
	go func() {
		if bufio.NewScanner(os.Stdin).Scan() {
			close(quit)
		}
	}()
	sig := make(chan os.Signal, 1)
	signal.Notify(sig, os.Interrupt)
	select {
	case <-quit:
	case <-sig:
	}
	fmt.Println("Assistant arrêté.")
}
