package main

import "strings"

// Logique de repérage de la surface partagée, indépendante du système (testable partout).

type rect struct{ L, T, R, B int }

func (r rect) W() int { return r.R - r.L }
func (r rect) H() int { return r.B - r.T }

type winInfo struct {
	H     uintptr
	Title string
	R     rect
}

func clamp(v float64) float64 {
	if v < 0 {
		return 0
	}
	if v > 1 {
		return 1
	}
	return v
}

func abs(v int) int {
	if v < 0 {
		return -v
	}
	return v
}

// pickWindow : parmi les fenêtres visibles (de la plus haute à la plus basse dans l'ordre d'empilement), retrouve celle qui est partagée.
// On compare le titre (le navigateur le donne comme nom de la source) et la taille de la vidéo capturée.
func pickWindow(ws []winInfo, surf, label string, vw, vh int) (int, bool) {
	best, bestScore := -1, 100
	lab := strings.TrimSpace(label)
	for i, w := range ws {
		score := 100
		exact := lab != "" && strings.EqualFold(strings.TrimSpace(w.Title), lab)
		contains := lab != "" && len(lab) >= 4 && (strings.Contains(strings.ToLower(w.Title), strings.ToLower(lab)) || (len(w.Title) >= 4 && strings.Contains(strings.ToLower(lab), strings.ToLower(w.Title))))
		sized := vw > 0 && vh > 0 && abs(w.R.W()-vw) <= 12 && abs(w.R.H()-vh) <= 12
		ratio := vw > 0 && vh > 0 && w.R.W() > 0 && w.R.H() > 0 && abs(w.R.W()*vh-w.R.H()*vw)*100 <= vw*w.R.H()*2 // même proportions à 2 % près
		switch {
		case exact && sized:
			score = 0
		case exact:
			score = 5
		case sized && surf != "browser":
			score = 10
		case contains:
			score = 20
		case ratio && surf != "browser":
			score = 30
		}
		if score < bestScore {
			best, bestScore = i, score
		}
	}
	return best, best >= 0
}

// pickMonitor : l'écran dont la taille est celle de la vidéo partagée ; à défaut l'écran principal (indice 0 = principal).
func pickMonitor(ms []rect, vw, vh int) int {
	for i, m := range ms {
		if abs(m.W()-vw) <= 2 && abs(m.H()-vh) <= 2 {
			return i
		}
	}
	return 0
}

// surfaceRect : zone de l'écran occupée par la surface partagée. Pour un onglet, la vidéo est le contenu de la page, ancré en bas à droite de la fenêtre.
func surfaceRect(surf string, win rect, vw, vh int) rect {
	if surf == "browser" && vw > 0 && vh > 0 && vw <= win.W() && vh <= win.H() {
		return rect{win.R - vw, win.B - vh, win.R, win.B}
	}
	return win
}

func mapPoint(r rect, x, y float64) (int, int) {
	w, h := r.W()-1, r.H()-1
	if w < 0 {
		w = 0
	}
	if h < 0 {
		h = 0
	}
	return r.L + int(clamp(x)*float64(w)+0.5), r.T + int(clamp(y)*float64(h)+0.5)
}
