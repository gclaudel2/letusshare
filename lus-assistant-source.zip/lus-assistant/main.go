package main

// Let Us Share – Assistant de dépannage (Windows).
//
// Ce programme est VISIBLE et lancé À LA MAIN par la personne qui demande de l'aide.
// Il ne s'installe pas, ne démarre pas tout seul, n'ouvre aucun accès depuis Internet :
//   - il n'écoute que sur cet ordinateur (127.0.0.1), jamais sur le réseau ;
//   - il n'agit que si la page Let Us Share, ouverte sur ce même ordinateur, saisit le code
//     d'appairage affiché dans cette fenêtre ;
//   - il n'injecte souris/clavier que pendant un contrôle que la personne a acceptée dans la réunion ;
//   - fermer cette fenêtre (ou Entrée) l'arrête immédiatement et relâche toutes les touches.
import (
	"crypto/rand"
	"crypto/subtle"
	"encoding/json"
	"flag"
	"fmt"
	"log"
	"math/big"
	"net"
	"net/http"
	"os"
	"sync"
	"time"
)

const version = "1.0"

var kinds = map[string]bool{"mm": true, "md": true, "mu": true, "wh": true, "kd": true, "ku": true, "release": true}

type server struct {
	inj   Injector
	mu    sync.Mutex
	code  string
	busy  bool
	fails int
}

func newCode() string {
	n, err := rand.Int(rand.Reader, big.NewInt(1000000))
	if err != nil {
		n = big.NewInt(time.Now().UnixNano() % 1000000)
	}
	return fmt.Sprintf("%06d", n.Int64())
}

func spaced(c string) string { return c[:3] + " " + c[3:] }

// say : met à jour l'état affiché (fenêtre sous Windows, console ailleurs).
func say(format string, a ...any) { uiStatus(fmt.Sprintf(format, a...), false) }

func sayActive(format string, a ...any) { uiStatus(fmt.Sprintf(format, a...), true) }

func (s *server) handle(w http.ResponseWriter, r *http.Request) {
	switch r.URL.Path {
	case "/":
		w.Header().Set("Content-Type", "text/plain; charset=utf-8")
		fmt.Fprintf(w, "Let Us Share – Assistant de dépannage %s\n", version)
	case "/ws":
		s.session(w, r)
	default:
		http.NotFound(w, r)
	}
}

func (s *server) session(w http.ResponseWriter, r *http.Request) {
	ws, err := wsAccept(w, r)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	s.mu.Lock()
	if s.busy {
		s.mu.Unlock()
		ws.writeText(`{"t":"busy"}`)
		ws.close()
		return
	}
	s.busy = true
	s.mu.Unlock()

	origin := r.Header.Get("Origin")
	if origin == "" {
		origin = "(inconnue)"
	}
	say("Une page demande à se connecter (origine : %s)…", origin)

	authed, active := false, false
	tname, tfound := "", true
	defer func() {
		s.inj.ReleaseAll()
		ws.close()
		s.mu.Lock()
		s.busy = false
		s.mu.Unlock()
		if authed {
			say("Page déconnectée. Plus aucun contrôle possible. En attente d’une page Let Us Share…")
		}
	}()

	ws.c.SetReadDeadline(time.Now().Add(20 * time.Second))
	for {
		op, payload, err := ws.read(8192)
		if err != nil {
			return
		}
		switch op {
		case 0x8:
			return
		case 0x9:
			ws.write(0xA, payload)
			continue
		case 0x1:
		default:
			continue
		}
		var e Event
		if json.Unmarshal(payload, &e) != nil {
			continue
		}
		if !authed {
			if e.T != "hello" {
				return
			}
			s.mu.Lock()
			ok := subtle.ConstantTimeCompare([]byte(e.Tok), []byte(s.code)) == 1
			renewed := ""
			if !ok {
				s.fails++
				if s.fails >= 5 { // trop d'essais : nouveau code
					s.code = newCode()
					s.fails = 0
					renewed = spaced(s.code)
				}
			} else {
				s.fails = 0
			}
			s.mu.Unlock()
			if renewed != "" { // hors du verrou : l'interface peut attendre le fil de la fenêtre
				uiCode(renewed)
				say("Trop d’essais incorrects : un nouveau code a été créé.")
			}
			if !ok {
				say("Code incorrect refusé. En attente d’une page Let Us Share…")
				ws.writeText(`{"t":"bad"}`)
				return
			}
			authed = true
			w0, h0 := s.inj.Screen()
			ws.writeText(fmt.Sprintf(`{"t":"ready","w":%d,"h":%d,"v":%q}`, w0, h0, version))
			say("Connecté à la page Let Us Share. En attente d’un contrôle accepté dans la réunion.")
			continue
		}
		ws.c.SetReadDeadline(time.Now().Add(90 * time.Second))
		switch e.T {
		case "ping":
			ws.writeText(`{"t":"pong"}`)
		case "tgt": // ce que la personne partage : écran entier, fenêtre, onglet
			name, ok := s.inj.SetTarget(e.Surf, e.VW, e.VH, e.Label)
			tname, tfound = name, ok
			ws.writeText(fmt.Sprintf(`{"t":"tgt","ok":%v,"name":%q}`, ok, name))
			if active {
				sayActive("%s", activeMsg(tname, tfound))
			}
		case "on":
			if !active {
				active = true
				sayActive("%s", activeMsg(tname, tfound))
			}
		case "off":
			if active {
				active = false
				s.inj.ReleaseAll()
				say("Contrôle terminé. L’assistant attend.")
			}
		case "ev":
			if active && kinds[e.K] {
				s.inj.Dispatch(e)
			}
		}
	}
}

func activeMsg(name string, found bool) string {
	switch {
	case name == "" && !found:
		return "CONTRÔLE ACTIF, mais la fenêtre partagée est introuvable : aucune action n’est envoyée. Fermez cette fenêtre pour tout arrêter."
	case name == "" || name == "écran entier":
		return "CONTRÔLE ACTIF : un participant pilote votre souris et votre clavier. Fermez cette fenêtre pour tout arrêter."
	}
	return "CONTRÔLE ACTIF sur « " + name + " » : un participant pilote cette fenêtre avec votre souris et votre clavier. Fermez cette fenêtre pour tout arrêter."
}

// Adresse de la page Let Us Share, modifiable avec l'option -url (déploiement en entreprise).
const defaultPageURL = "https://gclaudel2.github.io/letusshare/let-us-share.html"

// newAssistCode : code d'assistance à 8 chiffres, fait pour être dicté au téléphone (par paires : 48 29 13 57).
func newAssistCode() string {
	n, err := rand.Int(rand.Reader, big.NewInt(100000000))
	if err != nil {
		n = big.NewInt(time.Now().UnixNano() % 100000000)
	}
	return fmt.Sprintf("%08d", n.Int64())
}

func pairs(c string) string {
	out := ""
	for i := 0; i < len(c); i += 2 {
		if i > 0 {
			out += " "
		}
		end := i + 2
		if end > len(c) {
			end = len(c)
		}
		out += c[i:end]
	}
	return out
}

// appCtx : ce que l'interface a besoin de connaître.
type appCtx struct {
	version string
	pair    string // code de liaison (6 chiffres), pour le mode « l'aidant a déjà envoyé un lien »
	start   func() // appelé par le bouton « Demander de l'assistance » ; renvoie le code d'assistance à afficher
	assist  string // code d'assistance (8 chiffres)
	auto    bool   // démarre tout de suite (mise au point)
}

func main() {
	port := flag.String("port", "47653", "port local (127.0.0.1 uniquement)")
	pageURL := flag.String("url", defaultPageURL, "adresse de la page Let Us Share")
	auto := flag.Bool("assist", false, "demande l'assistance dès le lancement (mise au point)")
	flag.Parse()
	log.SetFlags(0)

	inj := newInjector()
	s := &server{inj: inj, code: newCode()}

	ln, err := net.Listen("tcp", "127.0.0.1:"+*port)
	if err != nil {
		uiFatal("L’assistant est déjà ouvert (le port " + *port + " est utilisé). Fermez l’autre fenêtre puis recommencez.")
		os.Exit(1)
	}
	srv := &http.Server{Handler: http.HandlerFunc(s.handle), ReadHeaderTimeout: 10 * time.Second}
	go srv.Serve(ln)

	ctx := &appCtx{version: version, pair: spaced(s.code), assist: newAssistCode(), auto: *auto}
	ctx.start = func() {
		s.mu.Lock()
		tok := s.code
		s.mu.Unlock()
		// Le code et le jeton passent dans la partie « # » de l'adresse : le navigateur ne l'envoie à aucun serveur.
		openURL(*pageURL + "#aide=" + ctx.assist + "&t=" + tok)
		say("Session ouverte dans votre navigateur. Donnez le code à la personne qui vous aide.")
	}
	uiRun(ctx) // bloque jusqu'à la fermeture de la fenêtre
	inj.ReleaseAll()
}
