module lusassistant

go 1.24
