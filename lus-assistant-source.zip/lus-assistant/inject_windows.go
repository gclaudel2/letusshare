//go:build windows

package main

// Implémentation Windows : rejoue souris et clavier via les fonctions standard de user32.dll.
// Aucune dépendance externe, aucun pilote, aucun droit administrateur.
import (
	"syscall"
)

var (
	user32              = syscall.NewLazyDLL("user32.dll")
	pSetCursorPos       = user32.NewProc("SetCursorPos")
	pMouseEvent         = user32.NewProc("mouse_event")
	pKeybdEvent         = user32.NewProc("keybd_event")
	pGetSystemMetrics   = user32.NewProc("GetSystemMetrics")
	pSetProcessDPIAware = user32.NewProc("SetProcessDPIAware")
	pVkKeyScanW         = user32.NewProc("VkKeyScanW")
	pMapVirtualKeyW     = user32.NewProc("MapVirtualKeyW")
)

const (
	mouseMove       = 0x0001
	mouseLeftDown   = 0x0002
	mouseLeftUp     = 0x0004
	mouseRightDown  = 0x0008
	mouseRightUp    = 0x0010
	mouseMiddleDown = 0x0020
	mouseMiddleUp   = 0x0040
	mouseXDown      = 0x0080
	mouseXUp        = 0x0100
	mouseWheel      = 0x0800
	mouseHWheel     = 0x1000

	keyUp       = 0x0002
	keyExtended = 0x0001
)

type winInjector struct {
	w, h int
	mods map[int]bool // modificateurs enfoncés (VK)
	held map[int]bool // touches nommées enfoncées (VK)
	btns map[int]bool // boutons souris enfoncés
}

func newInjector() Injector {
	pSetProcessDPIAware.Call()
	w, _, _ := pGetSystemMetrics.Call(0)
	h, _, _ := pGetSystemMetrics.Call(1)
	wi := &winInjector{w: int(w), h: int(h), mods: map[int]bool{}, held: map[int]bool{}, btns: map[int]bool{}}
	if wi.w == 0 {
		wi.w = 1920
	}
	if wi.h == 0 {
		wi.h = 1080
	}
	return wi
}

func (wi *winInjector) Screen() (int, int) { return wi.w, wi.h }

func clamp(v float64) float64 {
	if v < 0 {
		return 0
	}
	if v > 1 {
		return 1
	}
	return v
}

func (wi *winInjector) move(x, y float64) {
	px := int(clamp(x)*float64(wi.w-1) + 0.5)
	py := int(clamp(y)*float64(wi.h-1) + 0.5)
	pSetCursorPos.Call(uintptr(px), uintptr(py))
}

func (wi *winInjector) mouse(flags uint32, data int32) {
	pMouseEvent.Call(uintptr(flags), 0, 0, uintptr(uint32(data)), 0)
}

// boutons : 0 gauche, 1 milieu, 2 droit, 3/4 boutons latéraux
func btnFlags(b int) (down, up uint32, xdata int32, ok bool) {
	switch b {
	case 0:
		return mouseLeftDown, mouseLeftUp, 0, true
	case 1:
		return mouseMiddleDown, mouseMiddleUp, 0, true
	case 2:
		return mouseRightDown, mouseRightUp, 0, true
	case 3:
		return mouseXDown, mouseXUp, 1, true
	case 4:
		return mouseXDown, mouseXUp, 2, true
	}
	return 0, 0, 0, false
}

func isExtended(vk int) bool {
	switch {
	case vk >= 0x21 && vk <= 0x28: // PageUp..Down, End, Home, flèches
		return true
	case vk == 0x2D || vk == 0x2E: // Insert, Delete
		return true
	case vk == 0x5B || vk == 0x5C || vk == 0x5D: // Win gauche/droite, Menu
		return true
	}
	return false
}

func (wi *winInjector) keyRaw(vk int, up bool) {
	var f uint32
	if up {
		f = keyUp
	}
	if isExtended(vk) {
		f |= keyExtended
	}
	sc, _, _ := pMapVirtualKeyW.Call(uintptr(uint32(vk)), 0)
	pKeybdEvent.Call(uintptr(byte(vk)), uintptr(byte(sc)), uintptr(f), 0)
}

func (wi *winInjector) tap(vk int) {
	wi.keyRaw(vk, false)
	wi.keyRaw(vk, true)
}

var namedKeys = map[string]int{
	"Enter": 0x0D, "Escape": 0x1B, "Backspace": 0x08, "Tab": 0x09,
	"Delete": 0x2E, "Insert": 0x2D, "Home": 0x24, "End": 0x23,
	"PageUp": 0x21, "PageDown": 0x22,
	"ArrowLeft": 0x25, "ArrowUp": 0x26, "ArrowRight": 0x27, "ArrowDown": 0x28,
	"ContextMenu": 0x5D, "CapsLock": 0x14, "NumLock": 0x90, "ScrollLock": 0x91,
	"PrintScreen": 0x2C, "Pause": 0x13,
	"F1": 0x70, "F2": 0x71, "F3": 0x72, "F4": 0x73, "F5": 0x74, "F6": 0x75,
	"F7": 0x76, "F8": 0x77, "F9": 0x78, "F10": 0x79, "F11": 0x7A, "F12": 0x7B,
}

var modVK = map[string]int{"Shift": 0x10, "Control": 0x11, "Alt": 0x12, "Meta": 0x5B}

// typeChar : saisit un caractère imprimable en trouvant sa touche sur la disposition
// du clavier de CET ordinateur (AZERTY, QWERTZ, etc.), modificateurs compris.
func (wi *winInjector) typeChar(e Event) {
	r := []rune(e.Key)
	if len(r) == 0 {
		return
	}
	res, _, _ := pVkKeyScanW.Call(uintptr(uint16(r[0])))
	code := int16(res)
	if code == -1 {
		return
	}
	vk := int(code & 0xFF)
	state := (code >> 8) & 7
	if vk == 0xFF {
		return
	}
	want := map[int]bool{}
	if state&1 != 0 {
		want[0x10] = true // Shift
	}
	if state&2 != 0 {
		want[0x11] = true // Control
	}
	if state&4 != 0 {
		want[0x12] = true // Alt
	}
	// Un raccourci en cours (Ctrl/Alt/Win tenu par l'utilisateur distant) ne doit pas être relâché.
	shortcut := (e.Ctrl && !e.Alt) || (e.Alt && !e.Ctrl) || e.Meta
	var rel, prs []int
	for _, m := range []int{0x10, 0x11, 0x12} {
		h := wi.mods[m]
		w := want[m]
		if w && !h {
			prs = append(prs, m)
		}
		if h && !w && !shortcut {
			rel = append(rel, m)
		}
	}
	for _, m := range rel {
		wi.keyRaw(m, true)
	}
	for _, m := range prs {
		wi.keyRaw(m, false)
	}
	wi.tap(vk)
	for _, m := range prs {
		wi.keyRaw(m, true)
	}
	for _, m := range rel {
		wi.keyRaw(m, false)
	}
}

func (wi *winInjector) Dispatch(e Event) {
	switch e.K {
	case "mm":
		wi.move(e.X, e.Y)
	case "md":
		wi.move(e.X, e.Y)
		if d, _, x, ok := btnFlags(e.B); ok {
			wi.btns[e.B] = true
			wi.mouse(d, x)
		}
	case "mu":
		wi.move(e.X, e.Y)
		if _, u, x, ok := btnFlags(e.B); ok {
			delete(wi.btns, e.B)
			wi.mouse(u, x)
		}
	case "wh":
		if e.Dy != 0 {
			v := -e.Dy * 1.2
			wi.mouse(mouseWheel, clampI(v))
		}
		if e.Dx != 0 {
			v := e.Dx * 1.2
			wi.mouse(mouseHWheel, clampI(v))
		}
	case "kd":
		if vk, ok := modVK[e.Key]; ok {
			wi.mods[vk] = true
			wi.keyRaw(vk, false)
		} else if vk, ok := namedKeys[e.Key]; ok {
			wi.held[vk] = true
			wi.keyRaw(vk, false)
		} else if len([]rune(e.Key)) == 1 {
			wi.typeChar(e)
		}
	case "ku":
		if vk, ok := modVK[e.Key]; ok {
			delete(wi.mods, vk)
			wi.keyRaw(vk, true)
		} else if vk, ok := namedKeys[e.Key]; ok {
			delete(wi.held, vk)
			wi.keyRaw(vk, true)
		}
	case "release":
		wi.ReleaseAll()
	}
}

func clampI(v float64) int32 {
	if v > 1200 {
		v = 1200
	}
	if v < -1200 {
		v = -1200
	}
	return int32(v)
}

// ReleaseAll : relâche tout ce qui reste enfoncé (sécurité en fin de contrôle ou à la déconnexion).
func (wi *winInjector) ReleaseAll() {
	for vk := range wi.held {
		wi.keyRaw(vk, true)
	}
	for vk := range wi.mods {
		wi.keyRaw(vk, true)
	}
	for b := range wi.btns {
		if _, u, x, ok := btnFlags(b); ok {
			wi.mouse(u, x)
		}
	}
	wi.held = map[int]bool{}
	wi.mods = map[int]bool{}
	wi.btns = map[int]bool{}
}
