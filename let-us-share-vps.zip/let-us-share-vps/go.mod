module p2prelay

go 1.24.7
