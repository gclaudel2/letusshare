package main

import "testing"

func TestPickWindow(t *testing.T) {
	ws := []winInfo{
		{1, "Calculatrice", rect{1500, 100, 1800, 600}},
		{2, "Sans titre - Bloc-notes", rect{100, 100, 900, 700}},
		{3, "Rapport.docx - Word", rect{50, 50, 1250, 850}},
	}
	// titre exact + taille
	if i, ok := pickWindow(ws, "window", "Sans titre - Bloc-notes", 800, 600); !ok || ws[i].H != 2 {
		t.Fatal("titre+taille", i, ok)
	}
	// titre inconnu : la taille décide (800x600 = Bloc-notes), au bord près
	if i, ok := pickWindow(ws, "window", "", 806, 595); !ok || ws[i].H != 2 {
		t.Fatal("taille", i, ok)
	}
	// vidéo réduite par le navigateur (mêmes proportions que Word 1200x800)
	if i, ok := pickWindow(ws, "window", "xxxx", 600, 400); !ok || ws[i].H != 3 {
		t.Fatal("proportions", i, ok)
	}
	// rien ne correspond
	if _, ok := pickWindow(ws, "window", "", 333, 777); ok {
		t.Fatal("ne doit rien trouver")
	}
	// onglet : le titre de l'onglet est contenu dans celui de la fenêtre
	ws2 := []winInfo{{7, "Mon site - Google Chrome", rect{0, 0, 1280, 800}}}
	if i, ok := pickWindow(ws2, "browser", "Mon site", 1264, 700); !ok || ws2[i].H != 7 {
		t.Fatal("onglet", i, ok)
	}
	// deux fenêtres de même taille : la plus haute dans l'empilement gagne
	ws3 := []winInfo{{1, "A", rect{0, 0, 800, 600}}, {2, "B", rect{300, 300, 1100, 900}}}
	if i, _ := pickWindow(ws3, "window", "", 800, 600); ws3[i].H != 1 {
		t.Fatal("empilement")
	}
}

func TestMapPoint(t *testing.T) {
	r := rect{100, 200, 900, 800} // fenêtre 800x600 en (100,200)
	if x, y := mapPoint(r, 0, 0); x != 100 || y != 200 {
		t.Fatal("coin haut-gauche", x, y)
	}
	if x, y := mapPoint(r, 1, 1); x != 899 || y != 799 {
		t.Fatal("coin bas-droit", x, y)
	}
	if x, y := mapPoint(r, .5, .5); x != 500 || y != 500 {
		t.Fatal("centre", x, y)
	}
	if x, y := mapPoint(r, 2, -1); x != 899 || y != 200 {
		t.Fatal("bornes", x, y)
	}
	// onglet : contenu 1264x700 ancré en bas à droite d'une fenêtre 1280x800
	sr := surfaceRect("browser", rect{0, 0, 1280, 800}, 1264, 700)
	if sr != (rect{16, 100, 1280, 800}) {
		t.Fatal("onglet", sr)
	}
}

func TestPickMonitor(t *testing.T) {
	ms := []rect{{0, 0, 1920, 1080}, {1920, 0, 4480, 1440}}
	if pickMonitor(ms, 2560, 1440) != 1 || pickMonitor(ms, 1920, 1080) != 0 || pickMonitor(ms, 999, 999) != 0 {
		t.Fatal("écrans")
	}
}
